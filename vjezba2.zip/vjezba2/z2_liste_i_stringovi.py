# =============================================================
# ZADATAK 2: Liste i stringovi   (~7 minuta)
# =============================================================

ocjene = [8, 6, 10, 7, 9, 6, 8]

# a) Ispiši prvu i zadnju ocjenu.
# TODO
print("Prvi je ", ocjene[0])
print("Drugi je ", ocjene[6])

# b) Ispiši prve tri ocjene (koristi rezanje / slicing).
# TODO
print("Prve tri ocjene: ", ocjene[:3] )

# c) Student je dobio još jednu ocjenu: 10. Dodaj je u listu.
# TODO
ocjene.append(10)
print(ocjene)
# d) Izračunaj i ispiši prosjek ocjena na 2 decimale.
#    Savjet: sum() i len()
# TODO
prosjek = sum(ocjene) / len(ocjene)
print(f"Prosjek ocjena je: {prosjek:.2f}")

# e) Ispiši da li student ima ocjenu 6 (True/False).
# TODO

ima_sesticu = 6 in ocjene

print(f"Student ima ocjenu 6: {ima_sesticu}")

# f) Zadana je rečenica. Ispiši koliko ima riječi
#    i koja je najduža riječ.
#    Savjet: split(), a za najdužu riječ max(rijeci, key=len)
recenica = "analiza podataka pomaže da donosimo bolje odluke"
# TODO
