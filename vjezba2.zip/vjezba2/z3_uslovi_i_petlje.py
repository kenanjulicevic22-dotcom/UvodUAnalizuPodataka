# =============================================================
# ZADATAK 3: Uslovi i petlje   (~10 minuta)
# =============================================================
import random

# a) Korisnik unese broj bodova (0-100). Ispiši ocjenu:
#      0-54 -> 5,  55-64 -> 6,  65-74 -> 7,
#      75-84 -> 8, 85-94 -> 9,  95-100 -> 10
# TODO
broj = input("Broj: ")
if broj >= 0 && broj <= 54:
    print("Ocjena je 5")

    elif broj >= 55 & & broj <= 64:
        print("Ocjena je 6")

    elif broj >= 65 & & broj <= 74
        print("Ocjena je 7")

    elif broj >= 75 & & broj <= 84:
        print("Ocjena je 8")

    elif broj >= 85 & & broj <= 94:
        print("Ocjena je 9")

    elif broj >= 95 & & broj <= 100
        print("Ocjena je 10")

# b) Pomoću for petlje izračunaj sumu svih PARNIH brojeva od 1 do 100.
#    (Rezultat treba biti 2550)
# TODO


# c) MINI IGRA "Pogodi broj"
#    Računar zamisli broj od 1 do 20 (već napisano ispod).
#    Pomoću while petlje traži od korisnika da pogađa dok ne pogodi.
#    Nakon svakog pokušaja ispiši "Više!" ili "Manje!".
#    Na kraju ispiši iz koliko pokušaja je pogodio.
tajni_broj = random.randint(1, 20)
# TODO
