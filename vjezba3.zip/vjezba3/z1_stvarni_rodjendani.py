# =============================================================
# ZADATAK 1: Stvarni rođendani - da li se paradoks potvrdio?
# Uvod u analizu podataka - Vježbe, Sedmica 3
# =============================================================
# U fajlu real_birthdays.txt su rođendani studenata (format DD-MM).
# Provjeri da li u našoj grupi postoje isti rođendani i uporedi
# rezultat sa teorijom (Birthday Paradox).
# =============================================================
from collections import Counter

# Putanja do fajla koji se nalazi u istom folderu kao ova skripta
FAJL = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                    "../../UuAP - Auditorne vjezbe 3 - dodatak/UuAP - Auditorne vjezbe 3 - dodatak/zadaci/real_birthdays.txt")

# --- Učitavanje ---------------------------------------------
# Učitaj sve datume iz fajla u listu datumi.
# Savjet: with open(FAJL, "r", encoding="utf-8") as f:
#         strip() i preskoči prazne redove
datumi = []
# TODO
list datumi = []
with open(FAJL, "r", encoding="utf-8") as f:
    for red in f

# a) Koliko je ukupno rođendana?            (očekivano: 38)
# TODO
ukupno = len(datumi)
print("Ukuono rođendana:", ukupno)

# b) Koliko je JEDINSTVENIH rođendana?      (očekivano: 34)
#    Savjet: set()
# TODO
jedinstveni =


# c) Postoje li duplikati? Ispiši True/False.
# TODO


# d) Koji se datumi ponavljaju? Ispiši ih SORTIRANO, npr:
#       03-01 -> 2 puta
#    Savjet: Counter(datumi), pa sorted(...)
# TODO


# e) Uporedi sa teorijom.
#    Vjerovatnoća da u grupi od n osoba NIKO nema isti rođendan je:
#       (365/365) * (364/365) * (363/365) * ... * ((365-n+1)/365)
#    Vjerovatnoća poklapanja = 1 - to.
#    Napiši funkciju i ispiši:
#       Teorijska vjerovatnoća za 38 osoba: 86.4%
def vjerovatnoca_poklapanja(n):
    niko_isti = 1.0
    for i in range(n):
        niko_isti = niko_isti * (365 - i) / 365
    return 1 - niko_isti


# TODO: ispiši rezultat za len(datumi) osoba


# BONUS: Koliko je rođendana u svakom mjesecu?
#    Savjet: mjesec je dio iza crtice -> datum.split("-")[1]
# TODO
